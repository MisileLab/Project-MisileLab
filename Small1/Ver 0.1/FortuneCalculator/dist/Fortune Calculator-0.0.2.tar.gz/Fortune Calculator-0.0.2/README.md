Minecraft Fortune Calculator for funny
# Docs
## class Ore
Type Ore for Calculator
```py
Coal = 1
Diamond = 1
Emerald = 1
Iron = 1
Copper = "Copper" #  (2~3)
Gold = 1
NetherGold = "NetherGold" #  (2~6)
NetherQuartz = 1
Lapis = "Lapis" #  (4~9)
AmyestCluster = 4
```
## class Calculator
Need arg = fortunelevel(int or float), ore(class Ore)
### def calculatingfortune
Optional arg = simulatingamount:int=1000000, noprint:bool=True
### properties
#### self
return self
#### fortune1
return fortune1
#### ore1
return ore