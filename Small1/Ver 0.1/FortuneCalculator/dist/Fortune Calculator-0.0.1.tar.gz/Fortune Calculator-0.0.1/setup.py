from setuptools import setup

setup(
    name='Fortune Calculator',
    version='0.0.1',
    packages=[''],
    url='https://github.com/MisileLab/Project-MisileLab/tree/main/Small1/Ver%200.1/FortuneCalculator',
    license='MisileLab License V1.0',
    author='MisileLab',
    author_email='misileminecord@gmail.com',
    description='Minecraft Fortune Calculator'
)
